var panier = [];
var clePanier = "boutique-informatique-cart";
var panierEnregistre = localStorage.getItem(clePanier);

if (panierEnregistre != null) {
    try {
        var panierCharge = JSON.parse(panierEnregistre);
        var panierValide = Array.isArray(panierCharge);

        if (panierValide) {
            for (var i = 0; i < panierCharge.length; i++) {
                var articleCharge = panierCharge[i];
                var quantiteChargee = articleCharge != null && typeof articleCharge.quantite != "undefined" ?
                    articleCharge.quantite : 1;

                if (articleCharge == null ||
                    typeof articleCharge.nom != "string" ||
                    typeof articleCharge.prix != "number" ||
                    !isFinite(articleCharge.prix) ||
                    articleCharge.prix < 0 ||
                    typeof quantiteChargee != "number" ||
                    !isFinite(quantiteChargee) ||
                    quantiteChargee < 1 ||
                    Math.floor(quantiteChargee) != quantiteChargee) {
                    panierValide = false;
                    break;
                }
            }
        }

        if (panierValide) {
            for (var i = 0; i < panierCharge.length; i++) {
                var articleCharge = panierCharge[i];
                var quantiteChargee = typeof articleCharge.quantite == "undefined" ? 1 : articleCharge.quantite;
                var articleExistant = null;

                for (var j = 0; j < panier.length; j++) {
                    if (panier[j].nom == articleCharge.nom && panier[j].prix == articleCharge.prix) {
                        articleExistant = panier[j];
                        break;
                    }
                }

                if (articleExistant == null) {
                    panier.push({
                        nom: articleCharge.nom,
                        prix: articleCharge.prix,
                        quantite: quantiteChargee
                    });
                } else {
                    articleExistant.quantite = articleExistant.quantite + quantiteChargee;
                }
            }

            localStorage.setItem(clePanier, JSON.stringify(panier));
        } else {
            localStorage.removeItem(clePanier);
            alert("Les données enregistrées du panier étaient invalides. Le panier a été réinitialisé.");
        }
    } catch (error) {
        localStorage.removeItem(clePanier);
        alert("Les données enregistrées du panier étaient illisibles. Le panier a été réinitialisé.");
    }
}

function afficherPanier() {
    var contenuPanier = document.getElementById("contenu-panier");
    var totalPanier = document.getElementById("total-panier");
    var lienPanier = document.getElementById("lien-panier");
    var total = 0;
    var nombreArticles = 0;

    for (var i = 0; i < panier.length; i++) {
        total = total + panier[i].prix * panier[i].quantite;
        nombreArticles = nombreArticles + panier[i].quantite;
    }

    if (contenuPanier != null) {
        contenuPanier.textContent = "";

        if (panier.length == 0) {
            contenuPanier.textContent = "Votre panier est vide.";
        } else {
            var listePanier = document.createElement("ul");
            listePanier.className = "cart-items";

            for (var i = 0; i < panier.length; i++) {
                var article = document.createElement("li");
                var nomArticle = document.createElement("span");
                var prixArticle = document.createElement("span");

                nomArticle.className = "cart-item-name";
                nomArticle.textContent = panier[i].nom;
                if (panier[i].quantite > 1) {
                    nomArticle.textContent = nomArticle.textContent + " (x" + panier[i].quantite + ")";
                }
                prixArticle.className = "cart-item-price";
                prixArticle.textContent = panier[i].prix * panier[i].quantite + " €";
                article.appendChild(nomArticle);
                article.appendChild(prixArticle);
                listePanier.appendChild(article);
            }

            contenuPanier.appendChild(listePanier);
        }
    }

    if (totalPanier != null) {
        totalPanier.textContent = "Total à payer : " + total + " €";
    }

    if (lienPanier != null) {
        if (nombreArticles == 0) {
            lienPanier.textContent = "Panier";
        } else {
            lienPanier.textContent = "Panier (" + nombreArticles + ")";
        }
    }
}

function mettreAJourConnexion() {
    var lienConnexion = document.getElementById("lien-connexion");
    var etatConnexion = document.getElementById("etat-connexion");
    var connecte = sessionStorage.getItem("boutique-informatique-connecte") == "true";

    if (lienConnexion != null) {
        if (connecte == true) {
            lienConnexion.textContent = "Déconnexion";
        } else {
            lienConnexion.textContent = "Connexion";
        }
    }

    if (etatConnexion != null) {
        if (connecte == true) {
            etatConnexion.textContent = "Connexion de démonstration réussie.";
        } else {
            etatConnexion.textContent = "Vous n'êtes pas connecté.";
        }
    }
}

function animerBoutonAjout(bouton) {
    if (bouton == null) {
        return;
    }

    bouton.classList.remove("ajout-animation");
    window.requestAnimationFrame(function() {
        bouton.classList.add("ajout-animation");
    });
}

function ajouterPanier(nom, prix, bouton) {
    var messagePanier = document.getElementById("message-panier");

    if (sessionStorage.getItem("boutique-informatique-connecte") != "true") {
        alert("Vous devez être connecté pour ajouter un article au panier.");

        if (messagePanier != null) {
            messagePanier.textContent = "Connectez-vous pour ajouter un article au panier.";
        }

        return;
    }

    var articleExistant = null;

    for (var i = 0; i < panier.length; i++) {
        if (panier[i].nom == nom && panier[i].prix == prix) {
            articleExistant = panier[i];
            break;
        }
    }

    if (articleExistant == null) {
        panier.push({ nom: nom, prix: prix, quantite: 1 });
        articleExistant = panier[panier.length - 1];
    } else {
        articleExistant.quantite = articleExistant.quantite + 1;
    }

    localStorage.setItem(clePanier, JSON.stringify(panier));
    afficherPanier();
    animerBoutonAjout(bouton);

    if (messagePanier != null) {
        messagePanier.textContent = nom + " ajouté au panier (quantité : " + articleExistant.quantite + ").";
    }
}

function viderPanier() {
    panier = [];
    localStorage.setItem(clePanier, JSON.stringify(panier));
    afficherPanier();

    var messagePanier = document.getElementById("message-panier");

    if (messagePanier != null) {
        messagePanier.textContent = "Le panier a été vidé.";
    }
}

var formulaireConnexion = document.getElementById("formulaire-connexion");

if (formulaireConnexion != null) {
    formulaireConnexion.addEventListener("submit", function(event) {
        event.preventDefault();

        var emailConnexion = document.getElementById("email-connexion").value;
        var motDePasseConnexion = document.getElementById("mot-de-passe-connexion").value;

        if (emailConnexion != "" && motDePasseConnexion != "") {
            sessionStorage.setItem("boutique-informatique-connecte", "true");
            mettreAJourConnexion();
            alert("Connexion réussie ! Bienvenue, " + emailConnexion);
        }
    });
}

var formulaireInscription = document.getElementById("form-inscription");

if (formulaireInscription != null) {
    formulaireInscription.addEventListener("submit", function(event) {
        event.preventDefault();

        var motDePasse = document.getElementById("mot_de_passe").value;
        var confirmation = document.getElementById("confirmation_mdp").value;

        if (motDePasse != confirmation) {
            alert("Erreur : Les mots de passe ne correspondent pas !");
            return;
        }

        alert("Inscription validée pour la démonstration. Aucun compte n'est enregistré.");
    });
}

var formulaireContact = document.getElementById("form-contact");

if (formulaireContact != null) {
    formulaireContact.addEventListener("submit", function(event) {
        event.preventDefault();
        alert("Démo : aucun message n'a été envoyé. Aucun service d'envoi n'est configuré.");
    });
}

var lienConnexion = document.getElementById("lien-connexion");

if (lienConnexion != null) {
    lienConnexion.addEventListener("click", function(event) {
        if (sessionStorage.getItem("boutique-informatique-connecte") == "true") {
            event.preventDefault();
            sessionStorage.removeItem("boutique-informatique-connecte");
            mettreAJourConnexion();
        }
    });
}

var boutonViderPanier = document.getElementById("vider-panier");

if (boutonViderPanier != null) {
    boutonViderPanier.addEventListener("click", viderPanier);
}

var formulaireMotDePasse = document.getElementById("reset-password-form");

if (formulaireMotDePasse != null) {
    formulaireMotDePasse.addEventListener("submit", function(event) {
        event.preventDefault();
        document.getElementById("reset-status").textContent =
            "Aucun lien n'a été envoyé : le service de réinitialisation n'est pas configuré.";
    });
}

afficherPanier();
mettreAJourConnexion();
